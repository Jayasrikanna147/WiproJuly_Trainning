import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Ex2NgClass } from './ex2-ng-class';

describe('Ex2NgClass', () => {
  let component: Ex2NgClass;
  let fixture: ComponentFixture<Ex2NgClass>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Ex2NgClass]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Ex2NgClass);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
