import { Component } from '@angular/core';

@Component({
  selector: 'app-ex2-ng-class',
  imports: [],
  templateUrl: './ex2-ng-class.html',
  styleUrl: './ex2-ng-class.css'
})
export class Ex2NgClass {

}
