import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,   // ✅ needed for standalone components
  imports: [RouterOutlet],
  templateUrl: './app.html',
  styleUrls: ['./app.css']  // ✅ must be plural
})
export class App {
  flag1 = true;
  flag2 = true;

  protected readonly title = signal('ex2-app');
}
