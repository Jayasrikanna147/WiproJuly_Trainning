import { Component } from '@angular/core';
import { NgStyle } from '@angular/common';   // ✅ import NgStyle
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, NgStyle],  // ✅ add NgStyle here
  templateUrl: './app.html',
  styleUrls: ['./app.css']
})
export class App {
  flag1 = true;
  fontSize1 = '20px';
  color1 = 'green';

  toggleColor() {
    this.flag1 = !this.flag1;
  }

  increaseFont() {
    this.fontSize1 = parseInt(this.fontSize1) + 2 + 'px';
  }
}
