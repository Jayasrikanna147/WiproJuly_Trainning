import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HomeComponent } from './home/home.component';
import { DisplayListComponent } from './display-list/display-list.component';

@NgModule({
  declarations: [
    HomeComponent,
    DisplayListComponent
  ],
  imports: [
    BrowserModule
  ],
  bootstrap: [HomeComponent]
})
export class AppModule { }