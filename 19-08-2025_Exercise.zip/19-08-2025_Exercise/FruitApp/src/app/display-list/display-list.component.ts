import { Component } from '@angular/core';

@Component({
  selector: 'app-display-list',
  templateUrl: './display-list.html',
  styleUrls: ['./display-list.css']
})
export class DisplayListComponent {
  fruits = [
    { name: 'Apple', image: 'https://via.placeholder.com/150/FF0000/FFFFFF?text=Apple', description: 'Rich in fiber and vitamin C.' },
    { name: 'Banana', image: 'https://via.placeholder.com/150/FFFF00/000000?text=Banana', description: 'High in potassium and energy boosting.' },
    { name: 'Orange', image: 'https://via.placeholder.com/150/FFA500/FFFFFF?text=Orange', description: 'Great source of vitamin C.' },
    { name: 'Grapes', image: 'https://via.placeholder.com/150/800080/FFFFFF?text=Grapes', description: 'Packed with antioxidants and nutrients.' }
  ];
}
