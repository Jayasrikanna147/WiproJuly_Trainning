import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-fruit',
  standalone: true,
  templateUrl: './fruit.html',
  styleUrls: ['./fruit.css']
})
export class FruitComponent {
  @Input() name!: string;
  @Input() image!: string;
  @Input() description!: string;
}
