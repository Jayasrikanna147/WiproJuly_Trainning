import { Component } from '@angular/core';
import { FruitComponent } from './fruit/fruit.component';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [FruitComponent],
  templateUrl: './home.html',
  styleUrls: ['./home.css']
})
export class HomeComponent {
  fruits = [
    { name: 'Apple', image: 'assets/fruits/apple.jpg', description: 'A sweet red fruit' },
    { name: 'Banana', image: 'assets/fruits/banana.jpg', description: 'A long yellow fruit' },
    { name: 'Orange', image: 'assets/fruits/orange.jpg', description: 'A juicy citrus fruit' },
    { name: 'Mango', image: 'assets/fruits/mango.jpg', description: 'A tropical delicious fruit' }
  ];
}
