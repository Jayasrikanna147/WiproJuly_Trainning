import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FruitComponent } from '../fruit/fruit';
import { IFruit } from '../models/ifruit';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, FruitComponent],
  templateUrl: './home.html',
  styleUrls: ['./home.css']
})
export class HomeComponent {
  fruits: IFruit[] = [
    { name: 'Apple', image: 'assets/fruits/apple.jpg', description: 'Red and sweet fruit' },
    { name: 'Banana', image: 'assets/fruits/banana.jpg', description: 'Yellow long fruit' },
    { name: 'Mango', image: 'assets/fruits/mango.jpg', description: 'King of fruits' },
    { name: 'Orange', image: 'assets/fruits/orange.jpg', description: 'Citrus fruit' }
  ];
}
