// export interface IFruit { name: string; image: string; description: string; } 
export interface IFruit {
    name: string;
    image: string;
    description: string;
  }
  