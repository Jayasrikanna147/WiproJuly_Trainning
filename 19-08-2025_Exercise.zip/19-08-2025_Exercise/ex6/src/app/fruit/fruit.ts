import { Component, Input } from '@angular/core';
import { IFruit } from '../models/ifruit';

@Component({
  selector: 'app-fruit',
  standalone: true,
  templateUrl: './fruit.html',
  styleUrls: ['./fruit.css']
})
export class FruitComponent {
  @Input() fruit!: IFruit;
}
