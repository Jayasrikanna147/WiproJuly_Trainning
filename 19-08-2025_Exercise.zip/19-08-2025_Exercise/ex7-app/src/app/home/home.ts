import { Component } from '@angular/core';
import { IFruit } from '../models/ifruit';
import { FruitComponent } from '../fruit/fruit';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [FruitComponent],
  templateUrl: './home.html',
  styleUrls: ['./home.css']
})
export class HomeComponent {
  fruits: IFruit[] = [
    { fruitCode: 'f01', fruitName: 'Apple', fruitPrice: 120 },
    { fruitCode: 'f02', fruitName: 'Mango', fruitPrice: 100 },
    { fruitCode: 'f03', fruitName: 'Banana', fruitPrice: 50 },
    { fruitCode: 'f04', fruitName: 'Orange', fruitPrice: 80 }
  ];

  removeFruit(code: string) {
    console.log("Removing fruit: " + code);
    this.fruits = this.fruits.filter(f => f.fruitCode !== code);
  }
}
