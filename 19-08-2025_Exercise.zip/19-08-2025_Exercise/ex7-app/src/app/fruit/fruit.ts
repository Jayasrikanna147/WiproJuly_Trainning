import { Component, EventEmitter, Input, Output } from '@angular/core';
import { IFruit } from '../models/ifruit';

@Component({
  selector: 'app-fruit',
  standalone: true,
  templateUrl: './fruit.html',
  styleUrls: ['./fruit.css']
})
export class FruitComponent {
  @Input() fruit: IFruit = {
    fruitCode: '',
    fruitName: '',
    fruitPrice: 0
  };

  @Output() removeClick = new EventEmitter<string>();

  onRemove(code: string) {
    console.log("Remove clicked: " + code);
    this.removeClick.emit(code);
  }
}
