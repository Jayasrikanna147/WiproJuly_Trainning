export interface IFruit {
    fruitCode: string;
    fruitName: string;
    fruitPrice: number;
  }
  