import { Component } from '@angular/core';
import { Task } from '../models/task.model';

@Component({
  selector: 'app-home',
  templateUrl: './home.html',
  styleUrls: ['./home.css']
})
export class HomeComponent {
  tasks: Task[] = [];
  description: string = '';
  category: string = 'Work';

  private static idCounter = 0;   // unique id generator

  addTask() {
    if (!this.description.trim()) return;

    const newTask: Task = {
      id: ++HomeComponent.idCounter,
      description: this.description,
      category: this.category
    };

    this.tasks.push(newTask);
    this.description = '';  // reset form
    this.category = 'Work';
  }

  deleteTask(id: number) {
    this.tasks = this.tasks.filter(task => task.id !== id);
  }
}
