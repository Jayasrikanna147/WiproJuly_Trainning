export interface Task {
    id: number;
    description: string;
    category: string;
  }
  