import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Task } from '../models/task.model';

@Component({
  selector: 'app-task',
  templateUrl: './task.html',
  styleUrls: ['./task.css']
})
export class TaskComponent {
  @Input() task!: Task;  // ✅ important
  @Output() delete = new EventEmitter<void>();

  onDelete() {
    this.delete.emit();
  }
}
